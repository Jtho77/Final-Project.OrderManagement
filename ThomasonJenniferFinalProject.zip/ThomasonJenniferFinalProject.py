
"""
Author: Jenn Thomason
Date written: 12/12/24
Assignment: Final Project
Short Desc: This application is an Efficient Order Manager designed to help small businesses manage orders efficiently.
"""

import tkinter as tk  # Import the tkinter library for GUI elements
from tkinter import messagebox  # Import messagebox for displaying messages
from PIL import Image, ImageTk  # Import PIL for image handling
import json  # Import json for handling order data

class OrderManagerApp:
    """
    Main application class for the Efficient Order Manager.
    Handles the main window setup and navigation.
    """
    def __init__(self, root):
        """
        Initialize the main application window and set up the UI elements.
        Parameters:
        root (tk.Tk): The main root window object.
        """
        self.root = root  # Main window object
        self.root.title("Efficient Order Manager")  # Set the window title
        self.root.geometry("400x400")  # Set the window size
       
        # Initialize order data
        self.orders = []  # List to store orders

        # Load images
        self.logo_photo = self.load_image("logo.png", (150, 150))  # Company logo image
        self.task_photo = self.load_image("task.png", (100, 100))  # Task icon image

        # Menu setup
        self.menu = tk.Menu(root)  # Main menu bar
        root.config(menu=self.menu)  # Configure the root window to use the menu

        # File menu
        self.file_menu = tk.Menu(self.menu, tearoff=0)  # File menu without tear-off option
        self.menu.add_cascade(label="File", menu=self.file_menu)  # Add File menu to the menu bar
        self.file_menu.add_command(label="Exit", command=root.quit)  # Add Exit command to the File menu

        # Help menu
        self.help_menu = tk.Menu(self.menu, tearoff=0)  # Help menu without tear-off option
        self.menu.add_cascade(label="Help", menu=self.help_menu)  # Add Help menu to the menu bar
        self.help_menu.add_command(label="About", command=self.show_about)  # Add About command to the Help menu

        # Main window layout
        self.main_frame = tk.Frame(root)  # Main frame to hold the UI elements
        self.main_frame.pack(fill=tk.BOTH, expand=True)  # Pack the frame to fill the window

        self.lbl_logo = tk.Label(self.main_frame, image=self.logo_photo, text="Company Logo", compound=tk.BOTTOM)
        self.lbl_logo.pack(pady=10)  # Display company logo with padding

        self.lbl_welcome = tk.Label(self.main_frame, text="Welcome to Efficient Order Manager!", font=("Helvetica", 16))
        self.lbl_welcome.pack(pady=10)  # Welcome message with custom font

        self.btn_order_entry = tk.Button(self.main_frame, text="Order Entry", command=self.open_order_entry)
        self.btn_order_entry.pack(pady=5)  # Button to open Order Entry window

        self.btn_order_history = tk.Button(self.main_frame, text="Order History", command=self.open_order_history)
        self.btn_order_history.pack(pady=5)  # Button to open Order History window

        self.btn_exit = tk.Button(self.main_frame, text="Exit", command=self.root.destroy)
        self.btn_exit.pack(pady=5)  # Exit button to close the application

    def load_image(self, file_path, size):
        """
        Load and resize an image.
        Parameters:
        file_path (str): Path to the image file.
        size (tuple): Desired size of the image.
        Returns:
        ImageTk.PhotoImage: The resized image.
        """
        try:
            image = Image.open(file_path)  # Open the image file
            image = image.resize(size, Image.Resampling.LANCZOS)  # Resize the image
            return ImageTk.PhotoImage(image)  # Convert to PhotoImage for tkinter
        except IOError:
            messagebox.showerror("Error", f"Unable to load image: {file_path}")  # Show error message if loading fails
            return ImageTk.PhotoImage(Image.new("RGB", size))  # Return a blank image

    def show_about(self):
        """
        Display the 'About' information.
        """
        messagebox.showinfo("About", "Efficient Order Manager v1.0\nCreated by Jenn Thomason")  # Show the About message

    def open_order_entry(self):
        """
        Open the Order Entry window for entering new orders.
        """
        order_entry_window = tk.Toplevel(self.root)  # Create a new window for order entry
        order_entry_window.title("Order Entry")  # Set the window title
        order_entry_window.geometry("400x400")  # Set the same size as the main window

        # Labels and entry fields for order details
        tk.Label(order_entry_window, text="Customer Name").grid(row=0, column=0, padx=10, pady=10)  # Customer name label
        tk.Label(order_entry_window, text="Item").grid(row=1, column=0, padx=10, pady=10)  # Item label
        tk.Label(order_entry_window, text="Quantity").grid(row=2, column=0, padx=10, pady=10)  # Quantity label

        customer_name_entry = tk.Entry(order_entry_window)  # Entry for customer name
        item_entry = tk.Entry(order_entry_window)  # Entry for item name
        quantity_entry = tk.Entry(order_entry_window)  # Entry for quantity

        customer_name_entry.grid(row=0, column=1, padx=10, pady=10)  # Positioning the entries
        item_entry.grid(row=1, column=1, padx=10, pady=10)
        quantity_entry.grid(row=2, column=1, padx=10, pady=10)

        submit_button = tk.Button(order_entry_window, text="Submit", command=lambda: self.submit_order(customer_name_entry, item_entry,quantity_entry))
        submit_button.grid(row=3, column=0, columnspan=2, pady=10)  # Submit button

        exit_button = tk.Button(order_entry_window, text="Exit", command=order_entry_window.destroy)
        exit_button.grid(row=4, column=0, columnspan=2, pady=10)  # Exit button

        self.lbl_task = tk.Label(order_entry_window, image=self.task_photo, text="Task Icon", compound=tk.BOTTOM)
        self.lbl_task.grid(row=5, column=0, columnspan=2, pady=10)  # Display task icon

        # Save entries for clearing later
        self.customer_name_entry = customer_name_entry  # Entry widget for customer name
        self.item_entry = item_entry  # Entry widget for item name
        self.quantity_entry = quantity_entry  # Entry widget for quantity

    def open_order_history(self):
        """
        Open the Order History window to display past orders.
        """
        order_history_window = tk.Toplevel(self.root)  # Create a new window for order history
        order_history_window.title("Order History")  # Set the window title
        order_history_window.geometry("400x400")  # Set the same size as the main window

        tk.Label(order_history_window, text="Order History").pack(pady=10)  # Order history header

        # Load orders from file
        self.load_orders()  # Load orders from a JSON file

        # Display orders
        for order in self.orders:
            order_text = f"Customer: {order['customer_name']}, Item: {order['item']}, Quantity: {order['quantity']}"
            tk.Label(order_history_window, text=order_text).pack(pady=5)  # Display each order

        exit_button = tk.Button(order_history_window, text="Exit", command=order_history_window.destroy)
        exit_button.pack(pady=10)  # Exit button

    def load_orders(self):
        """
        Load orders from a JSON file.
        """
        try:
            with open("orders.json", "r") as file:  # Open the JSON file in read mode
                self.orders = json.load(file)  # Load orders from the file
        except FileNotFoundError:
            self.orders = []  # Initialize as empty if file not found
        except json.JSONDecodeError:
            messagebox.showerror("Error", "Failed to decode the orders file.")  # Show error if decoding fails

    def submit_order(self, customer_name_entry, item_entry, quantity_entry):
        """
        Submit a new order and save it to the list of orders.
        """
        customer_name = customer_name_entry.get()  # Get customer name from entry
        item = item_entry.get()  # Get item name from entry
        quantity = quantity_entry.get()  # Get quantity from entry

        if not customer_name or not item or not quantity:  # Check if any field is empty
            messagebox.showwarning("Input Error", "All fields are required!")
            return

        try:
            quantity = int(quantity)  # Ensure quantity is an integer
        except ValueError:
            messagebox.showwarning("Input Error", "Quantity must be a number!")
            return

        # Save the order details
        order = {"customer_name": customer_name, "item": item, "quantity": quantity}  # Create a dictionary to store the order details
        self.orders.append(order)  # Add the new order to the list of orders

        # Save orders to a file
        try:
            with open("orders.json", "w") as file:  # Open the JSON file in write mode
                json.dump(self.orders, file)  # Dump the list of orders into the file
            messagebox.showinfo("Success", "Order Submitted Successfully!")  # Show a success message

            # Clear the input fields
            customer_name_entry.delete(0, tk.END)  # Clear the customer name entry field
            item_entry.delete(0, tk.END)  # Clear the item entry field
            quantity_entry.delete(0, tk.END)  # Clear the quantity entry field
        except IOError:
            messagebox.showerror("Error", "Failed to save the order.")  # Show an error message if saving fails

# Run the application
if __name__ == "__main__":
    root = tk.Tk()  # Create the main root window
    app = OrderManagerApp(root)  # Create an instance of the OrderManagerApp
    root.mainloop()  # Run the application
